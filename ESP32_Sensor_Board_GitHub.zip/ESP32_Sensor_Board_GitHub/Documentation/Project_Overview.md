# Project Overview

## Purpose
Document an ESP32 sensor-board PCB concept using the provided KiCad screenshots as visual references.

## Reference sections
- `ESP32-Schematic.png` — ESP32 module, USB/flash/SD-card and test-point sheets.
- `Power-section-Schematic.png` — USB connector, charging/power circuitry, regulator and power indicator.
- `Sensor-Section.png` — BME280, photo sensor and microphone/amplifier circuits.
- `User-interface.png` — OLED/GPIO connectors and boot/reset controls.
- `PCB-layout.png` — 2D PCB layout reference.
- `PCB-3d-front.png` — 3D PCB view reference.

## Important engineering checks before manufacturing
- Confirm USB-C CC resistors and connector pin mapping.
- Confirm battery charger IC, battery chemistry, charge current and thermal design.
- Check regulator input/output limits, capacitor ratings and dissipation.
- Confirm ESP32 module antenna keep-out and copper restrictions from its datasheet.
- Verify all sensor footprints, pin numbering, I2C pull-ups, decoupling capacitors and logic levels.
- Run KiCad ERC and DRC on the actual editable project.
- Verify board outline, mounting holes, copper clearances, track widths, via sizes and fabrication rules.
- Review BOM manufacturer part numbers and footprints against datasheets.

The images alone do not contain enough machine-readable connectivity or board geometry to recreate a reliable, editable KiCad design. Obtain the original project files before manufacturing.
