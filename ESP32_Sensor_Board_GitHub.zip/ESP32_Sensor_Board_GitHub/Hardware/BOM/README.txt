Add an exported BOM (CSV/XLSX) here after checking part numbers, values, footprints, and quantities.
