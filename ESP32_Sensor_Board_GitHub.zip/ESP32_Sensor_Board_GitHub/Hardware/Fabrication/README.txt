Add final Gerber (.gbr) and drill files here after ERC/DRC and manufacturing review.
